# MedicalVision / SYZ2026 - Panel Bazli Teslim Paketi

Missense varyant patojenite tahmini. Dort panel (CFTR, KANSER, PAH, MASTER) icin AYRI modeller.

## Yapi
- `code/` : egitim framework'u (modeling + data_preprocessing + config/experiment.yaml)
- `ortak/`: all_runs.xlsx (tum kosular), best_per_panel.xlsx, multimodel.xlsx, SUREC_VE_KARARLAR.md
- `CFTR/ KANSER/ PAH/ MASTER/` : her panel icin README + tum kosular (xlsx) + explain/ (SHAP)

## Metodoloji (ozet)
- Sizintisiz: tum on-isleme/secim CV-ici, test yalniz nihai olcum.
- Model secimi: esikten bagimsiz cv_auc (PR-AUC tie-break). Karar esigi: F1 icin OOF'ta secilip teste degistirilmeden uygulanir.
- Veri: sifreli, asimetrik (benign azinlik). Dis veri EKLENMEDI (donguselluk/sizinti riski).

## Calistirma
```
pip install pandas numpy scikit-learn catboost xgboost lightgbm imbalanced-learn shap optuna openpyxl pyyaml matplotlib
# DATA/Raw/ altina panel xlsx dosyalarini koyun (veri repoda degildir)
python SRC/modeling/runner.py --profile first_pass
```
Detayli surec/karar gunlugu icin: ortak/SUREC_VE_KARARLAR.md
