# PAH Paneli

## Uygulananlar
9 model x augmentasyonlar; GENISLETILMIS arama (bayesian, robust, synthetic/clustering+synthetic); patojenik-agirlikli augmentasyon; karar esigi taramasi.

## Ise yarayan / yaramayan
Patojenik ekleme ve genisletilmis arama YARAMADI (eklenen MASTER patojenikleri PAH sinyalini seyreltti). Karar esigini dusurmek ISE YARADI: recall 0.625->1.0 (FN=0), MCC 0.349->0.380.

## Secilen model (sartname F1 onceligi)
Extra Trees / clustering. Esik: klinik icin dusuk (recall 1.0); saf F1 icin yuksek esik (F1 0.500).
- En iyi ablasyon: **class_weight**
- Test metrikleri: (dusuk esik) F1=0.485  MCC=0.380  recall=1.00 (FN=0)  ROC-AUC=0.79  |  (yuksek esik) F1=0.500

## Yeniden calistirma
```
python SRC/modeling/runner.py --profile first_pass   (PAH dahil) ; improve_pah (genisletilmis)
```
Model secimi sizintisiz cv_auc ile yapilir; test metrikleri yalniz raporlama icindir.
Bu klasor: `PAH_tum_kosular.xlsx` (tum konfigler) + `explain/` (SHAP/onem/karmasiklik matrisi).
