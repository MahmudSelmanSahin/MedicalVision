# MASTER Paneli

## Uygulananlar
9 model x original x OFAT (clustering UYGULANAMAZ - MASTER kaynaktir); class_weight; ek olarak capraz-panel benign (+203), uzman-stacking (alt-panel olasiliklari), F1-esik.

## Ise yarayan / yaramayan
Ucu de ISE YARADI ve birikti: capraz-panel benign (cv_auc+precision), uzman-stacking (recall), F1-esik. Birlikte: F1 0.563->0.582, MCC 0.448->0.467, recall 0.592->0.745.

## Secilen model (sartname F1 onceligi)
CatBoost + capraz-panel benign + uzman-stacking + F1-esik.
- En iyi ablasyon: **class_weight**
- Test metrikleri: F1=0.582  MCC=0.467  macro-F1=0.733  recall=0.745  ROC-AUC=0.85

## Yeniden calistirma
```
python SRC/modeling/runner.py --profile first_pass   (MASTER dahil)
```
Model secimi sizintisiz cv_auc ile yapilir; test metrikleri yalniz raporlama icindir.
Bu klasor: `MASTER_tum_kosular.xlsx` (tum konfigler) + `explain/` (SHAP/onem/karmasiklik matrisi).
