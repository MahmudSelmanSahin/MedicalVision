# CFTR Paneli

## Uygulananlar
4 senaryo (std/robust x median/nan) x 9 model x (original/clustering/transfer/synthetic) x OFAT ablasyon; DENGELI %20 test (benign kit oldugu icin); ek olarak sinif-dengeli clustering (gercek MASTER benign'i ~1:1).

## Ise yarayan / yaramayan
CatBoost/clustering (cv_auc lideri 0.994) patojenige yanli (F1 0.815). Sinif-dengeli clustering denendi ama duz RF/original'i GECEMEDI. Asil sampiyon RF/original: F1 0.880, recall 1.0 (FN=0), precision 0.786.

## Secilen model (sartname F1 onceligi)
Random Forest / original / feature_selection (sartname F1 onceligi). Alternatif: CatBoost/clustering (cv_auc 0.994 lideri).
- En iyi ablasyon: **feature_selection (esik 0.88)**
- Test metrikleri: F1=0.880  MCC=0.756  macro-F1=0.861  recall=1.00  precision=0.786  cv_auc=0.916

## Yeniden calistirma
```
python SRC/modeling/runner.py --profile first_pass   (CFTR dahil; dengeli deneme: cftr_balanced profili)
```
Model secimi sizintisiz cv_auc ile yapilir; test metrikleri yalniz raporlama icindir.
Bu klasor: `CFTR_tum_kosular.xlsx` (tum konfigler) + `explain/` (SHAP/onem/karmasiklik matrisi).
