# KANSER Paneli

## Uygulananlar
9 model x (original/clustering/transfer) x OFAT ablasyon; klinik %80/20 test.

## Ise yarayan / yaramayan
clustering + SMOTE en iyi; ek mudahale gerekmedi.

## Secilen model (sartname F1 onceligi)
CatBoost / clustering / SMOTE.
- En iyi ablasyon: **smote**
- Test metrikleri: F1=0.722  MCC=0.653  macro-F1=0.817  recall=0.867  ROC-AUC=0.95

## Yeniden calistirma
```
python SRC/modeling/runner.py --profile first_pass   (KANSER dahil)
```
Model secimi sizintisiz cv_auc ile yapilir; test metrikleri yalniz raporlama icindir.
Bu klasor: `KANSER_tum_kosular.xlsx` (tum konfigler) + `explain/` (SHAP/onem/karmasiklik matrisi).
